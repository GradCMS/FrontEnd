import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-tables',
  templateUrl: './user-tables.component.html',
  styleUrls: ['./user-tables.component.css']
})
export class UserTablesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
