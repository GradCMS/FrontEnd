import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-susbend',
  templateUrl: './user-susbend.component.html',
  styleUrls: ['./user-susbend.component.css']
})
export class UserSusbendComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
